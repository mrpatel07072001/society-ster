"""societyster URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/4.0/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""




from django.urls import path
from . import views



urlpatterns = [
    # path('', views.home, name='home')
    path('m_all-members/',views.m_all_members,name="m_all-members"),
    path('m-dashboard/',views.m_dashboard,name='m-dashboard'),
    path('m_all-notice/',views.m_all_notice,name='m_all-notice'),
    path('m_all-notice-detail/<int:pk>/',views.m_all_notice_detail,name='m_all-notice-detail'),
    path('m-all-event/', views.m_all_event, name='m-all-event'),
    path('m-all-event-details/<int:pk>', views.m_all_event_details, name='m-all-event-details'),
    path('m-add-compain/', views.m_add_complain, name='m-add-complain'),
    path('m-all-complain/', views.m_all_complain, name='m-all-complain'),
    path('m-contact-list/',views.m_contact_list,name='m-contact-list'),
    path('m-profile/',views.m_profile,name='m-profile'),
    path('add-family-member/',views.add_family_member,name='add-family-member'),
    path('maintenance/', views.maintenance, name='maintenance'),
    path('initiate-payment/<int:pk>',views.initiate_payment,name="initiate-payment"),
    path('callback/',views.callback,name="callback"),  
    path('m_upload_page/', views.m_upload_page, name='m_upload_page'),
    path('m_add_image/', views.m_add_image, name='m_add_image'),
    path('m_add_video/', views.m_add_video, name='m_add_video'),
    path('m_view_images/', views.m_view_images, name='m_view_images'),
    path('m_view_videos/', views.m_view_videos, name='m_view_videos'),
]

