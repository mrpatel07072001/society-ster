from calendar import HTMLCalendar
import datetime
from datetime import date, datetime

import email
from gettext import translation
from multiprocessing import context
import os
from django.conf import settings

from django.shortcuts import render,redirect
from Chairman.models import *
from MemberApp.models import *
from django.views.decorators.csrf import csrf_exempt
from django.http import JsonResponse

from Watchman.models import *

from .paytm import generate_checksum, verify_checksum
# Create your views here.

def m_dashboard(request):
    if "email" in request.session:
        uid = User.objects.get(email = request.session['email'])
        mid = Member.objects.get(user_id = uid)
        mcount = Member.objects.all().count()
        ncount = Notice.objects.all().count()
        ecount = Event.objects.all().count()
        now = datetime.now()
        month = now.month
        year = now.year
        date = now.date
        cal = HTMLCalendar().formatmonth(year,month)
        mem_id = Member.objects.all()
        imageData = Image.objects.all()
        eid = Event.objects.all()
        nid = Notice.objects.all()
        complaintData = Complain.objects.all()
        vid=visitor.objects.all()
        context = {
                'uid':uid,
                'mid':mid,
                'mcount':mcount,
                'ncount':ncount,
                'ecount':ecount,
                'month':month,
                'cal':cal,
                'date':date,
                'year':year,
                'mem_id':mem_id,
                'complaintData':complaintData,
                'imageData':imageData,
                'eid':eid,
                'nid':nid,
                'vid':vid,
            }
        return render(request,"MemberApp/m_index.html",{'context':context})
    
def m_all_members(request):
    if "email" in request.session:
        uid = User.objects.get(email = request.session['email'])
        if uid.role == "member":
            mid = Member.objects.get(user_id = uid)
            m_all = Member.objects.exclude(user_id = uid)
            
            context = {
                'uid':uid,
                'mid':mid,
                'm_all':m_all,
                
            }
            return render(request,"MemberApp/m_all-member.html",{'context':context})



def m_all_notice(request):
    if "email" in request.session:
        uid = User.objects.get(email = request.session['email'])
        mid = Member.objects.get(user_id = uid)
        n_all = Notice.objects.all().order_by('created_at').reverse()
        context = {
            'uid':uid,
            'mid':mid,
            'n_all':n_all
        }

        return render(request,"MemberApp/m_all-notice.html",{'context':context})
    else:
        return redirect('login')

def m_all_notice_detail(request,pk):
    if "email" in request.session:
        uid = User.objects.get(email = request.session['email'])
        mid = Member.objects.get(user_id = uid)
        nid = Notice.objects.get(id = pk)
        nall = NoticeView.objects.filter(notice_id = nid,member_id = mid)
        if nall:
            print("already Readed...")
        else:
            print("1st time notice read by member")
            nvid = NoticeView.objects.create(notice_id = nid,member_id = mid)
        context = {
            'uid':uid,
            'mid':mid,
            'nid':nid
        }

        return render(request,"MemberApp/m_all-notice-detail.html",{'context':context})
    else:
        return redirect('login')

def m_all_event(request):
    if "email" in request.session:
        uid = User.objects.get(email = request.session['email'])
        mid = Member.objects.get(user_id = uid)

        e_all = Event.objects.all().order_by('created_at').reverse()
        context = {
            'uid':uid,
            'mid':mid,
            'e_all':e_all
        }

        return render(request,"MemberApp/m-all-event.html",{'context':context})
    else:
        return redirect('login')

def m_all_event_details(request,pk):
    if "email" in request.session:
        uid = User.objects.get(email = request.session['email'])
        mid = Member.objects.get(user_id = uid)
        eid = Event.objects.get(id = pk)

        eall = EventView.objects.filter(member_id = mid, event_id = eid)

        if eall:
            print("Already Read")
        else:
            evid = EventView.objects.create(event_id = eid, member_id = mid)

        context={
            'uid':uid,
            'mid':mid,
            'eid':eid
        }
        return render(request,"MemberApp/m-all-event-details.html",{'context':context})
    else:
        return redirect('login')

def m_add_complain(request):
    if "email" in request.session:
        uid = User.objects.get(email = request.session['email'])
        mid = Member.objects.get(user_id = uid)

        if request.POST:
            if "pic" in request.FILES and "video" not in request.FILES:
                cid = Complain.objects.create(
                    title = request.POST['title'],
                    description = request.POST['description'],
                    pic = request.FILES['pic']
                )
            
            elif "video" in request.FILES and "pic" not in request.FILES:
                cid = Complain.objects.create(
                    title = request.POST['title'],
                    description = request.POST['description'],
                    videofile = request.FILES['video']
                )
            
            elif "video" in request.FILES and "pic" in request.FILES:
                cid = Complain.objects.create(
                    title = request.POST['title'],
                    description = request.title['description'],
                    pic = request.FILES['pic'],
                    videofile = request.FILES['video']
                )
            
            else:
                cid = Complain.objects.create(
                    title = request.POST['title'],
                    description = request.POST['description'],
                )
            return redirect('m-add-complain')
    
        else:
            context = {
                'uid':uid,
                'mid':mid
            }
            return render(request,"MemberApp/m-add-complain.html",{'context':context})
    
    else:
        return redirect('login')

def m_all_complain(request):
    uid = User.objects.get(email = request.session['email'])    
    mid = Member.objects.get(user_id = uid)
    com_all = Complain.objects.all()
    context = {
        'mid':mid,
        'com_all':com_all
    }
    return render(request,"MemberApp/m-all-complain.html",{'context':context})

def m_contact_list(request):
    uid = User.objects.get(email = request.session['email'])
    mid = Member.objects.get(user_id=uid)
    
    m_all = Member.objects.all()
    context = {
        'mid':mid,
        'uid':uid,
        'm_all':m_all,
    }
    return render(request,"MemberApp/m_contact-list.html",{'context':context})

def m_profile(request):
    if "email" in request.session:
        uid = User.objects.get(email = request.session['email'])

        if request.POST:
            currentpassword = request.POST['currentpassword']
            newpassword = request.POST['newpassword']
            if uid.password == currentpassword:
                uid.password = newpassword
                uid.save()
                return redirect('m-profile')
        else:
            if uid.role == "chairman":
                cid = Chairman.objects.get(user_id = uid)
                context = {
                        'uid':uid,
                        'cid':cid,
                    }
                return render(request,"Chairman/c_profile.html",{'context':context})

            elif uid.role == "member":
                mid = Member.objects.get(user_id = uid)
                fid = Member.objects.get(user_id=uid)
                f_m_all=list(FamilyMember.objects.filter(family_id=fid).values())
                context = {
                        'uid':uid,
                        'mid':mid,
                        'f_m_all':f_m_all,
                    }
                return render(request,"MemberApp/m_profile.html",{'context':context})

@csrf_exempt
def add_family_member(request):
    print("inside the add-family-member......")
    uid=User.objects.get(email=request.session['email'])
    fid = Member.objects.get(user_id=uid)
    fm=FamilyMember.objects.create(
        family_id = fid,
        firstname = request.POST['firstname'],
        lastname = request.POST['lastname'],
        mobileno = request.POST['mobileno'],
        gender = request.POST['gender'],
        age = request.POST['age'],
    )
    
    data=list(FamilyMember.objects.filter(family_id=fid).values())
    print(data)
    context={
            'msg':"successfully Added",
            'data':data
    }
    return JsonResponse({'context':context})


def maintenance(request):
    if "email" in request.session:
        uid = User.objects.get(email = request.session['email'])
        mid = Member.objects.get(user_id = uid)
        currentdate = date.today()
        print('================',currentdate)
        pid = Maintenance.objects.filter(user_id = uid).order_by('created_at').reverse()
        print('==========pd',pid)
        
        x = currentdate
        # print('yyyyyyyyyyyyyyyy',y)
        # print('zzzzzzzzzzzzzzzzzzzzzzzzz',z)
        
        for m in pid:

            y = m.duedate
            z = z = date.fromisoformat(y)

            if m.status == "Pending":
                print('penddddddddddddddddddddiiiiiiiiiin')
                if  x > z: 
                    print('===============dueeeeeeeeeee')
                    m.status = "Due"

            if m.status == "Due":
                total = int(m.amount) + int(m.penalty)
                m.total = total
                m.save()
            elif m.status == "Paid":
                total = int(m.amount)
                m.total = total
                m.save()
         
        context = {
            'uid':uid,
            'mid':mid,
            'pid':pid,
        }

        return render(request,"MemberApp/maintenance.html",{'context':context,})

    else:
        return redirect('login')

@csrf_exempt
def initiate_payment(request,pk):
    if "email" in request.session:
        global paymentid
        userid = User.objects.get(email = request.session['email'])
        mid = Member.objects.get(user_id = userid)
        maintenance = Maintenance.objects.get(id=pk)
        paymentid = pk
        amount = maintenance.total

        transaction = Transaction.objects.create(made_by=userid, member_id=mid ,amount=amount,maintenance_id=maintenance)  ##
        transaction.save()
   
        merchant_key = settings.PAYTM_SECRET_KEY

        params = (
            ('MID', settings.PAYTM_MERCHANT_ID),
            ('ORDER_ID', str(transaction.order_id)),
            ('CUST_ID', str(transaction.made_by.email)),
            ('TXN_AMOUNT', str(transaction.amount)),
            ('CHANNEL_ID', settings.PAYTM_CHANNEL_ID),
            ('WEBSITE', settings.PAYTM_WEBSITE),
            # ('EMAIL', request.user.email),
            # ('MOBILE_N0', '9911223388'),
            ('INDUSTRY_TYPE_ID', settings.PAYTM_INDUSTRY_TYPE_ID),
            ('CALLBACK_URL', 'http://127.0.0.1:8000/member/callback/'),
            # ('PAYMENT_MODE_ONLY', 'NO'),
        )

        paytm_params = dict(params)
        checksum = generate_checksum(paytm_params, merchant_key)

        transaction.checksum = checksum
        transaction.save()

        paytm_params['CHECKSUMHASH'] = checksum
        print('SENT: ', checksum)
        return render(request, 'MemberApp/redirect.html', context=paytm_params)
    else:
        return redirect('login')

@csrf_exempt
def callback(request):
    if request.method == 'POST':
        uid = User.objects.get(email = request.session['email'])
        mid = Member.objects.get(user_id = uid)
        context = {
                    'uid':uid,
                    'mid':mid,
                }
        received_data = dict(request.POST)
        paytm_params = {}
        paytm_checksum = received_data['CHECKSUMHASH'][0]
        for key, value in received_data.items():
            if key == 'CHECKSUMHASH':
                paytm_checksum = value[0]
            else:
                paytm_params[key] = str(value[0])
        # Verify checksum
        is_valid_checksum = verify_checksum(paytm_params, settings.PAYTM_SECRET_KEY, str(paytm_checksum))        
        if is_valid_checksum:
            received_data['message'] = "Checksum Matched"
            if received_data['STATUS'] ==  ['TXN_SUCCESS']:
                maintenance=Maintenance.objects.get(id=paymentid)
                maintenance.status='Paid'
                maintenance.save()
                print("----------------------------------->",maintenance)
                t_id=Transaction.objects.get(maintenance_id=maintenance)
                #uid=User.objects.get(email=request.session['m_email'])
                print('-----------------',t_id.made_by)
                context={'received_data':received_data}
                print('-----------------------',received_data)
                
                # sendPaymentMail('Paytm Payment','email_callback',t_id.made_by,{'maintenance':maintenance,'txnid':received_data['TXNID'],'orderid':received_data['ORDERID'],'txnamount':received_data['TXNAMOUNT']})
        else:
            received_data['message'] = "Checksum Mismatched"
            return render(request, 'MemberApp/callback.html', context=received_data)
        return render(request, 'MemberApp/callback.html', context=received_data,uid=uid,mid=mid)


def m_upload_page(request):
    if "email" in request.session:
        uid = User.objects.get(email = request.session['email'])
        mid = Member.objects.get(user_id = uid)
        context = {
                    'uid':uid,
                    'mid':mid,
                }
        return render(request,"MemberApp/m_uploadpage.html",{'context':context})

def m_add_image(request):
    if "email" in request.session:
        if request.POST:
            name = request.POST['name']
            imagefile = request.FILES['imagefile']
            aid = Image.objects.create(name = name, imagefile = imagefile)
            imageData = Image.objects.all()
            uid = User.objects.get(email = request.session['email'])
            mid = Member.objects.get(user_id = uid)
            context = {
                    'uid':uid,
                    'mid':mid,
                    'imageData':imageData
                }
            return redirect('m_view_images')
        else:
            return redirect("m_upload_page")

def m_add_video(request):
    if "email" in request.session:
        if request.POST:
            name = request.POST['name']
            videofile = request.FILES['videofile']
            aid = Video.objects.create(name = name, videofile = videofile)
            videoData = Video.objects.all()
            uid = User.objects.get(email = request.session['email'])
            mid = Member.objects.get(user_id = uid)
            context = {
                    'uid':uid,
                    'mid':mid,
                    'videoData':videoData
                }
            return redirect('m_view_videos')
        else:
            return redirect("m_upload_page")

def m_view_images(request):
    uid = User.objects.get(email = request.session['email'])
    mid = Member.objects.get(user_id = uid)
    imageData = Image.objects.all()
    context = {
                    'uid':uid,
                    'mid':mid,
                    'imageData':imageData
                }
    return render(request,"MemberApp/m_images.html",{'context':context})

def m_view_videos(request):
    uid = User.objects.get(email = request.session['email'])
    mid = Member.objects.get(user_id = uid)
    videoData = Video.objects.all()
    context = {
                    'uid':uid,
                    'mid':mid,
                    'videoData':videoData
                }
    return render(request,"MemberApp/m_videos.html",{'context':context})