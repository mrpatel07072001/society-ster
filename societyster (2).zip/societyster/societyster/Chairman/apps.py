from django.apps import AppConfig


class ChairmanConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'Chairman'
