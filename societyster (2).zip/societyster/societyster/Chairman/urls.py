"""societyster URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/4.0/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from unicodedata import name
from django.contrib import admin
from django.urls import  path
from . import views
from django.conf import settings
from django.conf.urls.static import static
urlpatterns = [
    path('', views.home, name='home'),
    path('login/', views.login, name='login'),
    
    path('check-email/', views.check_email, name='check-email'),

    path('logout/',views.logout,name='logout'),

    path('c-profile/',views.c_profile,name='c-profile'),
    path('c-dashboard/',views.c_dashboard,name='c-dashboard'),
    path('forgot-password/',views.forgot_password,name='forgot-password'),
    path('reset-password/',views.reset_password,name='reset-password'),

    path('add-member/', views.add_member,name='add-member'),
    path('all-members/', views.all_members,name='all-members'),

    path('add-notice/',views.add_notice,name='add-notice'),
    path('all-notice/',views.all_notice,name='all-notice'),

    path('add-event/', views.add_event, name='add-event'),
    path('all-event/', views.all_event, name='all-event'),

    path('all-watchman/',views.all_watchman,name='all-watchman'),
    path('approved/<int:pk>/',views.approved,name='approved'),
    path('rejected/<int:pk>/',views.rejected,name='rejected'),
    
    path('del-notice/<int:pk>/',views.del_notice,name='del-notice'),
    path('del-event/<int:pk>/',views.del_event,name='del-event'),
    path('del-image/<int:pk>/',views.del_image,name='del-image'),
    path('del-video/<int:pk>/',views.del_video,name='del-video'),
    path('m-noticeview-details/<int:pk>/', views.m_noticeview_details, name='m-noticeview-details'),
    path('all-complain/', views.all_complain, name='all-complain'),

    path('contact-list/',views.contact_list,name='contact-list'),
    
    path('image-gallery/', views.image_gallery, name='image-gallery'),
    
    path('upload_page/', views.upload_page, name='upload_page'),
    path('add_image/', views.add_image, name='add_image'),
    path('add_video/', views.add_video, name='add_video'),
    path('view_images/', views.view_images, name='view_images'),
    path('view_videos/', views.view_videos, name='view_videos'),
    path('c-all-visitors/',views.c_all_visitors,name="c-all-visitors"),

    path('add-maintenance/',views.add_maintenance, name='add-maintenance'),
    path('view_maintenance/', views.view_maintenance, name='view_maintenance'),

    path('change-profile-pic/',views.change_profile_pic,name='change-profile-pic'),
    path('remove-profile-pic/',views.remove_profile_pic,name='remove-profile-pic'),
    path('wregister',views.wregister,name='wregister'),
]
# + static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
