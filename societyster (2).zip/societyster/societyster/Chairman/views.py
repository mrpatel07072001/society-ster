
import os
from typing import List
from django.conf import settings
from django.templatetags.static import static
from logging import exception
from random import randint,choice
from turtle import title, update
from MemberApp.models import *
from Watchman.models import *
from django.shortcuts import redirect, render
from .models import * 
from django.core.mail import send_mail
from MemberApp.utils import *
from django.views.decorators.csrf import csrf_exempt
from django.http import HttpResponseRedirect, JsonResponse
import calendar
from calendar import HTMLCalendar
from datetime import datetime


def home(request):
    return render(request,"Chairman/Home.html")
count=0
# Create your views here.
def login(request):
    global count
    if "email" in request.session:
        uid = User.objects.get(email = request.session['email'])
        if uid.role == "chairman":
            return redirect('c-dashboard')
        elif uid.role == "member":
            return redirect('m-dashboard')
        elif uid.role == "watchman":
            return redirect('w-dashboard')
    if request.POST:
        try:
            print("---->Inside request post....")
            p_email = request.POST['email']
            p_password = request.POST['password']

            uid = User.objects.get(email=p_email)

            if  uid:
                if uid.password == p_password:
                    if uid.role == "chairman":
                        count=0
                        print("password is correct...")
                        cid = Chairman.objects.get(user_id=uid)
                        if cid.gender == "Male":
                            cid.profile_pic = "media/default_male.png"
                            cid.save()
                        elif cid.gender == "Female":
                            cid.profile_pic = "media/default_female.png"
                            cid.save()
                        request.session['email']=uid.email #storing email in session
                        return redirect('c-dashboard')
                    elif uid.role == "member":
                        mid = Member.objects.get(user_id = uid)
                        if uid.first_time_login == False:
                            if mid.gender == "Male":
                                mid.profile_pic = "media/default_male.png"
                                mid.save()
                            elif mid.gender == "Female":
                                mid.profile_pic = "media/default_female.png"
                                mid.save()
                            email = uid.email
                            otp = randint(1111,9999)
                            uid.otp = otp
                            uid.save()
                            msg = "Your OTP is : "+str(otp)
                            send_mail("Forgot Password - SocietySter",msg,"societyster@gmail.com",[email])
                            sendOtpMail("Forgot Password - SocietySter","send-otp-template",email,{'fname':mid.firstname,'otp':otp})
                            return render(request,"MemberApp/m_reset-password.html",{'email':email})
                        else:
                            request.session['email'] = uid.email
                            return redirect('m-dashboard')
                    elif uid.role == "watchman":
                        print("inside watchman....")
                        wid = Watchman.objects.get(user_id = uid)
                        if uid.is_verified == False:
                            email = uid.email
                            otp = randint(1111,9999)
                            uid.otp = otp
                            uid.save()
                            msg = "Your OTP is"+str(otp)
                            send_mail("Reset-Password",msg,"anjali.20.learn@gmail.com",[email])
                            sendOtpMail("Reset - Password - SocietySter","send-otp-template",email,{'fname':wid.firstname,'otp':otp})
                            return render(request,"Chairman/reset-password.html",{'email':email})
                        else:
                            request.session['email'] = uid.email
                            print("-------->before redirect of dashboard")
                            return redirect('w-dashboard')
                else:
                    count+=1
                    print("password is incorrect *****")
                    e_msg="Incorrect Password"
                    if count>2:
                        e_msg = "You Entered Multiple Time Wrong Password. Reset Your Password"
                        return render(request,"Chairman/forgot-password.html",{'e_msg':e_msg})
                    else:
                        print("count===="+count)
                        return render(request,"Chairman/login.html",{'e_msg':e_msg})

            print("email---->",p_email)

            return render(request,"Chairman/login.html")
        except:
            e_msg="Invalid Email or Password"
            print("------->>>>>>>>>>>>>>>>>>>>",exception)
            return render(request,"Chairman/login.html",{'e_msg':e_msg})
    else:
        print("---->Outside request post....")
        return render(request,"Chairman/login.html")

@csrf_exempt
def check_email(request):
    email = request.POST['email']
    print("-----------> email ajax",email)
    # uid = User.objects.all()
    try:
        uid = User.objects.get(email = email)
        print('--------->>>',uid)
        context = {
        'msg': "success"
    }
    except:
        context = {
            'msg' : "Fail"
        }
    return JsonResponse({'context':context})

def logout(request):
    if "email" in request.session:
        del request.session['email']
        return redirect('login')
    else:
        return redirect('login')

def c_profile(request):
    if "email" in request.session:
        uid = User.objects.get(email = request.session['email'])
        
        if request.POST:
            currentpassword = request.POST['currentpassword']
            newpassword = request.POST['newpassword']
            if uid.password == currentpassword:
                uid.password = newpassword
                uid.save()
                return redirect('c-profile')
        else:
            if uid.role == "chairman":
                cid = Chairman.objects.get(user_id = uid)
                context = {
                        'uid':uid,
                        'cid':cid,
                    }
                return render(request,"Chairman/c_profile.html",{'context':context})

            elif uid.role == "member":
                cid = Chairman.objects.get(user_id = uid)
                context = {
                        'uid':uid,
                        'cid':cid,
                    }
                return render(request,"Chairman/c_profile.html",{'context':context})
                
    else:
        return redirect('login')

def upload_page(request):
    if "email" in request.session:
        uid = User.objects.get(email = request.session['email'])
        cid = Chairman.objects.get(user_id = uid)
        context = {
                    'uid':uid,
                    'cid':cid,
                }
        return render(request,"chairman/uploadpage.html",{'context':context})

def add_image(request):
    if "email" in request.session:
        if request.POST:
            name = request.POST['name']
            imagefile = request.FILES['imagefile']
            aid = Image.objects.create(name = name, imagefile = imagefile)
            imageData = Image.objects.all()
            uid = User.objects.get(email = request.session['email'])
            cid = Chairman.objects.get(user_id = uid)
            context = {
                    'uid':uid,
                    'cid':cid,
                    'imageData':imageData
                }
            return redirect('view_images')
        else:
            return redirect("upload_page")

def add_video(request):
    if "email" in request.session:
        if request.POST:
            name = request.POST['name']
            videofile = request.FILES['videofile']
            aid = Video.objects.create(name = name, videofile = videofile)
            videoData = Video.objects.all()
            uid = User.objects.get(email = request.session['email'])
            cid = Chairman.objects.get(user_id = uid)
            context = {
                    'uid':uid,
                    'cid':cid,
                    'videoData':videoData
                }
            return redirect('view_videos')
        else:
            return redirect("upload_page")

def view_images(request):
    uid = User.objects.get(email = request.session['email'])
    cid = Chairman.objects.get(user_id = uid)
    imageData = Image.objects.all()
    context = {
                    'uid':uid,
                    'cid':cid,
                    'imageData':imageData
                }
    return render(request,"chairman/images.html",{'context':context})

def view_videos(request):
    uid = User.objects.get(email = request.session['email'])
    cid = Chairman.objects.get(user_id = uid)
    videoData = Video.objects.all()
    context = {
                    'uid':uid,
                    'cid':cid,
                    'videoData':videoData
                }
    return render(request,"chairman/videos.html",{'context':context})

def c_dashboard(request):
    if "email" in request.session:
            uid = User.objects.get(email = request.session['email'])
            cid = Chairman.objects.get(user_id = uid)
            gender = cid.gender
            mcount = Member.objects.all().count()
            ncount = Notice.objects.all().count()
            ecount = Event.objects.all().count()
            now = datetime.now()
            month = now.month
            year = now.year
            date = now.date
            eid = Event.objects.all()
            nid = Notice.objects.all()
            complaintData = Complain.objects.all()
            cal = HTMLCalendar().formatmonth(year,month)
            mem_id = Member.objects.all()
            imageData = Image.objects.all()
            context = {
                        'uid':uid,
                        'cid':cid,
                        'eid':eid,
                        'nid':nid,
                        'mem_id':mem_id,
                        'complaintData':complaintData,
                        'imageData':imageData,
                        'gender':gender,
                        'mcount':mcount,
                        'ncount':ncount,
                        'ecount':ecount,
                        'month':month,
                        'cal':cal,
                        'date':date,
                        'year':year
                    }
            return render(request,"Chairman/index.html",{'context':context})



def forgot_password(request):
    if request.POST:
        email = request.POST['email']
        otp = randint(1111,9999)
        uid = User.objects.get(email = email)
        
        try:
            if uid:
                uid.otp = otp
                uid.save()
                msg = "Your OTP is : "+str(otp)
                
                img=logo.objects.all()
                sendOtpMail("Forgot Password - SocietySter","send-otp-template",email,{'otp':otp,'uid':uid,'img':img})
                return render(request,"Chairman/reset-password.html",{'email': email,'img':img })
        except:
            e_msg = "email does not exist"
            return render(request,"Chairman/forgot-password.html")
    else:
        return render(request,"Chairman/forgot-password.html")

def reset_password(request):
    if request.POST:
        email = request.POST['email']
        otp = request.POST['otp']
        newpassword = request.POST['newpassword']
        confirmpassword = request.POST['confirmpassword']

        uid = User.objects.get(email = email)

        if newpassword == confirmpassword:
            if str(uid.otp) == otp and uid.email == email:
                uid.password = newpassword
                uid.first_time_login = True
                uid.is_verified = True
                uid.save()
                return redirect('login')
            else:
                e_msg = "Invalid OTP"
                return render(request,"Chairman/reset-password.html",{'e_msg': e_msg,'email': email})
        else:
            e_msg= "New Password & Confirm Password Does Not Match !!!"
            return render(request,"Chairman/reset-password.html",{'e_msg': e_msg,'email': email})
    else:
        return redirect('forgot-password')


def all_members(request):
    uid = User.objects.get(email = request.session['email'])
    cid = Chairman.objects.get(user_id = uid)
    m_all = Member.objects.all()
    context = {
                                        'uid':uid,
                                        'cid':cid,
                                        'm_all': m_all,
    }
    return render(request,"Chairman/all-members.html",{'context':context}) 

def add_member(request):
    if "email" in request.session:
        uid = User.objects.get(email = request.session['email'])
        cid = Chairman.objects.get(user_id = uid)
        L1 = ["qwe789","asd456","zxc123","qaz741","wsx852","edc963"]
        if request.POST:
            email = request.POST['email']
            password = email[:4]+choice(L1)
            role = "member"
            house_no = request.POST['house_no']
            uid = User.objects.create(email= email,password = password,role=role)
            hid = House.objects.get(house_no = house_no)
            hid.status = "Active"
            hid.save()
            mid = Member.objects.create(
                            user_id = uid,
                            house_id = hid,
                            firstname = request.POST['firstname'],
                            lastname = request.POST['lastname'],
                            mobileno = request.POST['mobileno'],
                            job_specification = request.POST['job_specification'],
                            birthdate = request.POST['birthdate'],
                            job_address = request.POST['job_adress'],
                            no_of_members = request.POST['no_of_members'],
                            marrital_status = request.POST['m_status'],
                            locality = request.POST['locality'],
                            nationality = request.POST['nationality'],
                            gender = request.POST['gender'],
                            no_of_vehicles = request.POST['no_of_vehical'],
                            vehicle_type = request.POST['vehical_type'],
                            id_proof = request.FILES['id_proof'],
                )
            
            if mid:
                msg="Your Password is : "+password
                send_welcome_mail("Welcome to SocietySter","welcome-email",email,{'fname':mid.firstname,'email':email,'password':password})
                m_all = Member.objects.all()
                if mid.gender == "Male":
                            cid.profile_pic = "media/default_male.png"
                            cid.save()
                elif mid.gender == "Female":
                            cid.profile_pic = "media/default_female.png"
                            cid.save()
                context = {
                            'uid':uid,
                            'cid':cid,
                            'm_all': m_all,
                        }
                return redirect('all_members')
        else:
            house_all = House.objects.filter(status = "Pending")
            context = {
                            'uid':uid,
                            'cid':cid,
                            'house_all':house_all,
                        }  
            return render(request,"Chairman/add-member.html",{'context':context})
    else:
        return redirect('login')


    
def add_notice(request):
    if request.POST:
        if "pic" not in request.FILES and "video" not in request.FILES:
            nid = Notice.objects.create(
                title = request.POST['title'],
                description = request.POST['description']
            )
        elif "pic" in request.FILES and "video" not in request.FILES:
            nid = Notice.objects.create(
                title = request.POST['title'],
                description = request.POST['description'],
                pic = request.FILES['pic'],
            )
        elif "pic" not in request.FILES and "video" in request.FILES:
            nid = Notice.objects.create(
                title = request.POST['title'],
                description = request.POST['description'],
                videofile = request.FILES['video']
            )
        elif "pic" in request.FILES and "video" in request.FILES:
            nid = Notice.objects.create(
                title = request.POST['title'],
                description = request.POST['description'],
                pic = request.FILES['pic'],
                videofile = request.FILES['video']
            )
        all_member_emails = User.objects.exclude(role="Chairman")
        new_notice_notification("New Notice - SocietySter","new-notice-notification",all_member_emails,{'title':nid.title})

        return redirect("all-notice")
        
    else:
        uid = User.objects.get(email = request.session['email'])
        cid = Chairman.objects.get(user_id = uid)
        gender = cid.gender
        context = {
                            'uid':uid,
                            'cid':cid,
                            'gender':gender,
        }

        return render(request,"Chairman/add-notice.html",{'context':context})

def all_notice(request):
    uid = User.objects.get(email = request.session['email'])
    cid = Chairman.objects.get(user_id = uid)
    nall = Notice.objects.all().order_by('created_at').reverse()
    context = {
                'uid':uid,
                'cid':cid,
                'nall':nall,
        }

    return render(request,"Chairman/notice-list.html",{'context':context})

def m_noticeview_details(request,pk):
    if "email" in request.session:
        uid = User.objects.get(email = request.session['email'])
        cid = Chairman.objects.get(user_id = uid)

        nid = Notice.objects.get(id = pk)
        nvid = NoticeView.objects.filter(notice_id = nid)

        context = {
            'uid':uid,
            'cid':cid,
            'nid':nid,
            'nvid':nvid
        }

        return render(request,"chairman/m-noticeview-details.html",{'context':context})
    
    else:
        return redirect('login')

def all_watchman(request):
    if "email" in request.session:
        uid = User.objects.get(email = request.session['email'])
        cid = Chairman.objects.get(user_id = uid)
        wall = Watchman.objects.all()
        context = {
                            'uid':uid,
                            'cid':cid,
                            'wall':wall,
        }
        return render(request,"Chairman/all-watchman.html",{'context':context})

def approved(request,pk):
    if "email" in request.session:
        uid = User.objects.get(email = request.session['email'])
        cid = Chairman.objects.get(user_id = uid)
        wid = Watchman.objects.get(user_id = pk)
        wid.status = "approved"
        wid.save()
        L1 = ["qwe789","asd456","zxc123","qaz741","wsx852","edc963"]
        
        user_id = User.objects.get(id=pk)
        emailpass=wid.user_id.email
        email=[wid.user_id.email]
        password = emailpass[:4]+choice(L1) 
        user_id.password = password
        user_id.is_verfied = True
        user_id.save()
        watchman_request_approved("Welcome to SocietySter","watchman-request-approved",email,{'fname':wid.firstname,'email':emailpass,'password':password})
        wall = Watchman.objects.all()
        return redirect('all-watchman')
def rejected(request,pk):
    if "email" in request.session:
        uid = User.objects.get(email = request.session['email'])
        cid = Chairman.objects.get(user_id = uid)
        wid = Watchman.objects.get(user_id = pk)
        wid.status = "rejected"
        wid.save()
        wall = Watchman.objects.all()
        return redirect('all-watchman')

def del_notice(request,pk):
    if "email" in request.session:
        uid = User.objects.get(email = request.session['email'])
        cid = Chairman.objects.get(user_id = uid)
        nid = Notice.objects.get(id=pk)
        nid.delete()
        return redirect('all-notice')
        
    else:
        return redirect('login')

def add_event(request):
    if request.POST:
        if "pic" in request.FILES and "video" not in request.FILES:
            eid = Event.objects.create(
                title = request.POST['title'],
                description = request.POST['description'],
                pic = request.FILES['pic']
            )

        elif "video" in request.FILES and "pic" not in request.FILES:
            eid = Event.objects.create(
                title = request.POST['title'],
                description = request.POST['description'],
                videofile = request.FILES['video']
            ) 
        elif "video" in request.FILES and "pic" in request.FILES:
            eid = Event.objects.create(
                title = request.POST['title'],
                description = request.POST['description'],
                pic = request.FILES['pic'],
                videofile = request.FILES['video']
            )
        else:
            eid = Event.objects.create(
                title = request.POST['title'],
                description = request.POST['description'],
            )
        return redirect('add-event')
    else:
        uid = User.objects.get(email = request.session['email'])
        cid = Chairman.objects.get(user_id = uid)
        
        context = {
            'uid':uid,
            'cid':cid,
            
        }
        return render(request,"chairman/add-event.html",{'context':context})

def all_event(request):
    uid = User.objects.get(email = request.session['email'])
    cid = Chairman.objects.get(user_id = uid)
    e_all = Event.objects.all().order_by('created_at').reverse()
     
    context={
        'uid':uid,
        'cid':cid,
        'e_all':e_all,
       
    }
    return render(request,"chairman/all-event.html",{'context':context})

def del_event(request,pk):
    if "email" in request.session:
        uid = User.objects.get(email = request.session['email'])
        cid = Chairman.objects.get(user_id = uid)

        eid = Event.objects.get(id = pk)
        eid.delete()

        return redirect('all-event')
    else:
        return redirect('login')

def all_complain(request):
    uid = User.objects.get(email = request.session['email'])    
    cid = Chairman.objects.get(user_id = uid)
    com_all = Complain.objects.all()
    context = {
        'cid':cid,
        'com_all':com_all
    }
    return render(request,"Chairman/all-complain.html",{'context':context})

def contact_list(request):
    uid = User.objects.get(email = request.session['email'])
    cid = Chairman.objects.get(user_id=uid)
    m_all = Member.objects.all()
    context = {
        'uid':uid,
        'cid':cid,
        'm_all':m_all,
    }
    return render(request,"Chairman/contact-list.html",{'context':context})



def image_gallery(request):
    uid = User.objects.get(email = request.session['email'])
    cid = Chairman.objects.get(user_id = uid)
    path = settings.MEDIA_ROOT
    img_list = os.listdir(path + 'media/images')
    videos = os.listdir(path='media/videos')
    context = {'images' : img_list ,'uid':uid,'cid':cid,'videos':videos}
    return render(request, "Chairman/image-gallery.html", {'context':context})

def add_maintenance(request):
    if "email" in request.session:
        if request.POST:
            amount = request.POST['amount']
            penalty = request.POST['penalty']
            total = amount
            status = "Pending"
            m_all = Member.objects.all()
            for i in m_all:
                email = i.user_id.email
                uid = User.objects.get(email=email)
                mid = Member.objects.get(id = i.id)
                mtid = Maintenance.objects.create(
                    user_id = uid,
                    member_id = mid,
                    date = request.POST['date'],
                    duedate = request.POST['duedate'],
                    amount = amount,
                    penalty = penalty,
                    total = total,
                    status = status,
            )                                                               
            return redirect('add-maintenance')
        else:
            uid = User.objects.get(email = request.session['email'])
            cid = Chairman.objects.get(user_id = uid)
            context = {
                        'uid':uid,
                        'cid':cid,
            }
            return render(request,"Chairman/add-maintenance.html",{'context':context})
    else:
        return redirect('login')
def view_maintenance(request):
    uid = User.objects.get(email = request.session['email'])
    cid = Chairman.objects.get(user_id = uid)
    maintenanceData = Maintenance.objects.all()
    context = {
        'uid':uid,
        'cid':cid,
        'maintenanceData':maintenanceData,
    }
    return render(request,"Chairman/maintenance_list.html",{'context':context})

def change_profile_pic(request):
    if request.POST:
        
        uid = User.objects.get(email = request.session['email'])
        if uid.role=="chairman":
            new_profile = request.FILES['profile-pic']
            upid = Chairman.objects.get(user_id=uid)
            upid.profile_pic = new_profile
            upid.save()
            return redirect('c-profile')
        elif uid.role=="member":
            new_profile = request.FILES['profile-pic']
            upid = Member.objects.get(user_id=uid)
            upid.profile_pic = new_profile
            upid.save()
            return redirect('m-profile')
        elif uid.role == "watchman":
            new_profile = request.FILES['profile-pic']
            upid = Watchman.objects.get(user_id=uid)
            upid.profile_pic = new_profile
            upid.save()
            return redirect('w-profile')
    else:
        return render(request,"Chairman/changeprofile.html")

def remove_profile_pic(request):
    if request.POST:
        uid = User.objects.get(email = request.session['email'])
        upid = Chairman.objects.get(user_id=uid)
        if upid.gender == "Male":
            upid.profile_pic = "media/default_male.png"
            upid.save()
        elif upid.gender == "Female":
            upid.profile_pic = "media/default_female.png"
            upid.save()
        return redirect('c-profile')

def wregister(request):
    if request.POST:
        fname = request.POST['fname']
        lname = request.POST['lname']
        email = request.POST['email']
        mobileno = request.POST['mobileno']
        idproof = request.Files['idproof']
        if fname & lname & email & mobileno & idproof:
            return JsonResponse


def c_all_visitors(request):
    if "email" in request.session:
        uid = User.objects.get(email=request.session['email'])
        cid = Chairman.objects.get(user_id=uid)
        v_all = visitor.objects.all()
        
        context = {
            'uid':uid,
            'cid':cid,
            'v_all':v_all,
            
        }       
        return render(request,"Chairman/c-all-visitor.html",{'context':context})

def del_image(request,pk):
    if "email" in request.session:
        uid = User.objects.get(email = request.session['email'])
        cid = Chairman.objects.get(user_id = uid)
        iid = Image.objects.get(id=pk)
        iid.delete()
        return redirect('view_images')
        
    else:
        return redirect('login')
    
def del_video(request,pk):
    if "email" in request.session:
        uid = User.objects.get(email = request.session['email'])
        cid = Chairman.objects.get(user_id = uid)
        vid = Video.objects.get(id=pk)
        vid.delete()
        return redirect('view_videos')
        
    else:
        return redirect('login')