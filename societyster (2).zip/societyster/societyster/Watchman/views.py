from calendar import HTMLCalendar
from datetime import datetime
from django.shortcuts import redirect, render
from Chairman.models import *
from MemberApp.models import *
from .models import *
from django.core.mail import send_mail
from django.views.decorators.csrf import csrf_exempt
# Create your views here.
def sign_up(request):
    
    if request.POST:
        email = request.POST['email']
        password = ""
        role = "watchman"

        uid = User.objects.create(email = email, password = password, role =role)
        wid = Watchman.objects.create(
                user_id = uid,
                firstname = request.POST['firstname'],
                lastname = request.POST['lastname'],
                contact = request.POST['contact'],
                ID_pic = request.FILES['id_proof']
            )
        
        if wid:
                msg = "You have been Successfully registered, Your password will ge generated and sent to you when your Status will be Approved"
                send_mail("Welcome to SocietySter",msg,"anjali.20.learn@gmail.com",[email])
                s_msg = "You have been Successfully registered"

                context = {
                            'uid':uid,
                            'wid':wid,
                        }
                
                return  render(request,"Chairman/login.html",{'context':context,'s_msg':s_msg})

    else:

        return render(request,"watchman/sign-up.html")
        
def w_dashboard(request):
    if "email" in request.session:
        uid = User.objects.get(email = request.session['email'])
        wid = Watchman.objects.get(user_id = uid)
        mcount = Member.objects.all().count()
        ncount = Notice.objects.all().count()
        ecount = Event.objects.all().count()
        now = datetime.now()
        month = now.month
        year = now.year
        date = now.date
        cal = HTMLCalendar().formatmonth(year,month)
        mem_id = Member.objects.all()
        imageData = Image.objects.all()
        eid = Event.objects.all()
        nid = Notice.objects.all()
        complaintData = Complain.objects.all()
        vid=visitor.objects.all()
        context = {
            'uid':uid,
            'wid':wid,
            'mcount':mcount,
            'ncount':ncount,
            'ecount':ecount,
            'month':month,
            'cal':cal,
            'date':date,
            'year':year,
            'mem_id':mem_id,
            'complaintData':complaintData,
            'imageData':imageData,
            'eid':eid,
            'nid':nid,
            'vid':vid,
        }
        print("..........................................................brfore return render")
        return render(request,"Watchman/w_index.html",{'context':context})
def w_profile(request):
    if "email" in request.session:
        uid = User.objects.get(email = request.session['email'])

        if request.POST:
            cpassword = request.POST['cpassword']
            npassword = request.POST['npassword']
            if uid.password == cpassword:
                uid.password = npassword
                uid.save()
                return redirect('w-profile')
        else:
            if uid.role == "watchman":
                wid = Watchman.objects.get(user_id = uid)
                context = {
                            'uid':uid,
                            'wid':wid,
                        }
                return render(request,"watchman/w_profile.html",{'context':context})
            else:
                pass
    else:
        return redirect('login')


@csrf_exempt
def add_visitor(request):
    if request.POST:
        uid = User.objects.get(email=request.session['email'])
        house_no = request.POST['house_no']
        hid = House.objects.get(house_no=house_no)
        vid = visitor.objects.create(
            house_no=hid,
            firstname=request.POST['firstname'],
            lastname=request.POST['lastname'],
            contact_no=request.POST['contact_no'],
            no_of_person=request.POST['no_of_person'],

        )

        v_all = visitor.objects.all()
        n_all = Notice.objects.all().order_by('created_at').reverse()
        e_all = Event.objects.all().order_by('created_at').reverse()
        context = {
            'uid': uid,
            # 'house_no': house_id,
            'vid': vid,
            'v_all': v_all,
            'n_all':n_all,
            'e_all':e_all,
            }

        return redirect('add-visitor')
    else:
        uid = User.objects.get(email=request.session['email'])
        wid = Watchman.objects.get(user_id=uid)
        v_all = visitor.objects.all()
        n_all = Notice.objects.all().order_by('created_at').reverse()
        e_all = Event.objects.all().order_by('created_at').reverse()
        house_all = House.objects.all()
        context = {
            'uid': uid,
            'v_all': v_all,
            'wid': wid,
            'n_all':n_all,
            'e_all':e_all,
            'house_all':house_all
        }
        return render(request, "watchman/add-visitor.html", {'context': context})

def all_visitor(request):
    if "email" in request.session:
        uid = User.objects.get(email=request.session['email'])
        wid=Watchman.objects.get(user_id=uid)
        v_all = visitor.objects.all()
        n_all = Notice.objects.all().order_by('created_at').reverse()
        e_all = Event.objects.all().order_by('created_at').reverse()
        context = {
            'uid':uid,
            'wid':wid,
            'v_all':v_all,
            'n_all':n_all,
            'e_all':e_all,
        }       
        return render(request,"watchman/all-visitor.html",{'context':context})
def w_all_notice(request):
    if "email" in request.session:
        uid= User.objects.get(email=request.session['email'])
        wid = Watchman.objects.get(user_id=uid)
        w_all = Watchman.objects.all()
        n_all = Notice.objects.all().order_by('created_at').reverse()
        e_all = Event.objects.all().order_by('created_at').reverse()
        context = {
            'uid':uid,
            'wid':wid,
            'n_all':n_all,
            'w_all':w_all,
            'e_all':e_all,
        }   
        return render(request,"watchman/w_all-notice.html",{'context':context})
    else:
        return redirect('login')    


def w_all_notice_details(request, pk):
    if "email" in request.session:
        uid = User.objects.get(email=request.session['email'])
        wid = Watchman.objects.get(user_id=uid)
        nid = Notice.objects.get(id=pk)
        n_all = Notice.objects.all().order_by('created_at').reverse()
        e_all = Event.objects.all().order_by('created_at').reverse()
        context = {
            'uid': uid,
            'wid': wid,
            'nid': nid,
            'n_all':n_all,
            'e_all':e_all,
            


        }
        return render(request, "watchman/w-all-notice-details.html", {'context': context})
    else:
        return redirect('login')

def w_view_event(request):   
    uid = User.objects.get(email=request.session['email'])
    wid = Watchman.objects.get(user_id=uid)
    e_all = Event.objects.all().order_by('created_at').reverse()
    context = {
        'uid': uid,
        'wid': wid,
        'e_all': e_all,
    }
    return render(request, "watchman/w_view_event.html", {'context': context})

def w_view_event_detail(request, pk):
    if "email" in request.session:
        uid = User.objects.get(email=request.session['email'])
        wid = Watchman.objects.get(user_id=uid)
        eid = Event.objects.get(id=pk)
        e_all = Event.objects.all().order_by('created_at').reverse()
        
        context = {
            'uid': uid,
            'wid': wid,
            'eid':eid,
            'e_all':e_all,
        }
        return render(request, "watchman/w-all-event-details.html", {'context': context})
    else:
        return redirect('login')

def w_add_complain(request):
    if request.POST:
        if "pic" in request.FILES and "video" not in request.FILES:
            eid = Complain.objects.create(
                title=request.POST['title'],
                description=request.POST['description'],
                pic=request.FILES['pic'],


            )

        elif "video" in request.FILES and "pic" not in request.FILES:
            eid = Complain.objects.create(
                title=request.POST['title'],
                description=request.POST['description'],
                videofile=request.FILES['video'],

            )

        elif "pic" in request.FILES and "video" in request.FILES:
            eid = Complain.objects.create(
                title=request.POST['title'],
                description=request.POST['description'],
                pic=request.FILES['pic'],
                videofile=request.FILES['video'],

            )
        else:
            eid = Complain.objects.create(
                title=request.POST['title'],
                description=request.POST['description'],
            )
        # custom_mail("NEW EVENT", "notice_add_template",
         #           "vidhipatel6897@gmail.com", {'fname': 'vidhi', 'title': nid.title})
        return redirect("w-view-complain")

    else:
        uid = User.objects.get(email=request.session['email'])
        wid = Watchman.objects.get(user_id=uid)
        n_all = Notice.objects.all().order_by('created_at').reverse()
        e_all = Event.objects.all().order_by('created_at').reverse()
        context = {
            'uid': uid,
            'wid': wid,
            'n_all':n_all,
            'e_all':e_all,
        }

        return render(request, "watchman/w-add-complain.html", {'context': context})

def w_view_complain(request):
    uid = User.objects.get(email=request.session['email'])
    wid = Watchman.objects.get(user_id=uid)
    c_all = Complain.objects.all().order_by('created_at').reverse()
    n_all = Notice.objects.all().order_by('created_at').reverse()
    e_all = Event.objects.all().order_by('created_at').reverse()
    context = {
        'uid': uid,
        'wid': wid,
        'c_all': c_all,
        'n_all':n_all,
        'e_all':e_all,


    }
    return render(request, "watchman/w-view-complain.html", {'context': context})

def w_contact_list(request):
    uid = User.objects.get(email=request.session['email'])
    wid = Watchman.objects.get(user_id=uid)
    mid = Member.objects.all()
    n_all = Notice.objects.all().order_by('created_at').reverse()
    e_all = Event.objects.all().order_by('created_at').reverse()
    context = {
           'uid':uid,
           'wid':wid,
           'mid':mid,
           'n_all':n_all,
            'e_all':e_all,
       }
    return render(request,"watchman/w-contact-list.html",{'context':context})


def del_complain(request,pk):
    if "email" in request.session:
        uid = User.objects.get(email=request.session['email'])
        wid = Watchman.objects.get(user_id=uid)
        c_all = Complain.objects.all().order_by('created_at').reverse()

        cid = Complain.objects.get(id=pk)
        cid.delete()
        return redirect('w-view-complain')
    else:
        return redirect('login')