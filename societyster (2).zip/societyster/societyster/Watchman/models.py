from datetime import timezone
import math
from django.db import models

from Chairman.models import *
from MemberApp.models import House

# Create your models here.
class Watchman(models.Model):
    user_id = models.ForeignKey(User,on_delete=models.CASCADE)
    firstname = models.CharField(max_length=30)
    lastname = models.CharField(max_length=30)
    status = models.CharField(max_length=20, default="pending")
    contact = models.CharField(max_length=20)
    ID_pic = models.FileField(upload_to="media/documents",default="media/default.png")
    profile_pic = models.FileField(upload_to="media/images",default="media/default.png")

    def __str__(self):
        return self.firstname

class visitor(models.Model):
    house_no = models.ForeignKey(House, on_delete=models.CASCADE)
    firstname = models.CharField(max_length=30)
    lastname = models.CharField(max_length=30)
    contact_no = models.CharField(max_length=30)
    is_verfied = models.BooleanField(default=False)
    status = models.CharField(max_length=20)
    no_of_person = models.CharField(max_length=50)
    created_at = models.DateTimeField(auto_now_add=True,blank=False)

    def __str__(self):
        return self.firstname

