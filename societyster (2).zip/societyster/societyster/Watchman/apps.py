from django.apps import AppConfig


class WatchmanConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'Watchman'
