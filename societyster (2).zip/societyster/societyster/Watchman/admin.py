from django.contrib import admin

from Watchman.models import *

# Register your models here.
admin.site.register(Watchman)
admin.site.register(visitor)
admin.site.register